from __future__ import print_function

import pyspark
import fib_module

sc = pyspark.SparkContext("local", "Demo Spark App")

inputRDD = sc.parallelize(range(1, 11))
outputRDD = inputRDD.map(lambda n: fib_module.fib(n))
results=outputRDD.collect()

print("----- Answer------", "First 10 fibonacci:", results)
