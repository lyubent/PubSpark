from __future__ import print_function

def fib(n):
    """
    Compute the nth fibonacci number.

    :rtype: int
    """
    a,b=0,1
    for i in range(n):
        a,b=(b,a+b)
    return a

def test_fib(firstN):
    """
    Compute the first n fibonacci numbers.

    :rtype: list
    """
    return [fib(i) for i in range(1,firstN+1)]

if __name__=='__main__':
    first_ten=test_fib(10)
    print ("The first 10 fibonacci numbers are: ", first_ten)

