#!/bin/sh

rm libraries.zip
pushd libraries
zip ../libraries.zip *
popd

${SPARK_HOME}/sbin/start-master.sh
${SPARK_HOME}/sbin/start-slave.sh spark://localhost:8080

${SPARK_HOME}/bin/spark-submit --py-files libraries.zip app/demo_spark_app.py

${SPARK_HOME}/sbin/stop-slave.sh
${SPARK_HOME}/sbin/stop-master.sh
